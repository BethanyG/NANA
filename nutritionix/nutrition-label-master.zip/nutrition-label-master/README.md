Nutrition Label jQuery Plugin by Nutritionix
============================================

[See a Demo!](http://dev2.nutritionix.com/html/label-jquery-plugin/html/demo-mini.html)

Summary: Create a FDA-style nutrition label with any nutrition data source (even the [Nutritionix API](http://www.nutritionix.com/api)!)
